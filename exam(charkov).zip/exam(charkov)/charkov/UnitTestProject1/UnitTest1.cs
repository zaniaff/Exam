﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace UnitTestProject1
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
           
            double expected = 7.44;
            double actual = expected;

            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }
        public void TestMethod2()
        {

            double expected = -29;
            double actual = expected;

            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }
        public void TestMethod3()
        {

            double expected = 1000;
            double actual = expected;

            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }
        public void TestMethod4()
        {

            double expected = -100;
            double actual = expected;

            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }
        public void TestMethod5()
        {

            double expected = 2500000;
            double actual = expected;

            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }
        public void TestMethod6()
        {

            double expected = -250000;
            double actual = expected;

            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }
        public void TestMethod7()
        {

            double expected = 0;
            double actual = expected;

            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }
        public void TestMethod8()
        {

            double expected = 0.1;
            double actual = expected;

            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }
        public void TestMethod9()
        {

            double expected = -0.1;
            double actual = expected;

            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }
        public void TestMethod10()
        {

            double expected = 1000000000000000000;
            double actual = expected;

            Assert.AreEqual(expected, actual, 0.001, "Account not debited correctly");
        }

    }
}
