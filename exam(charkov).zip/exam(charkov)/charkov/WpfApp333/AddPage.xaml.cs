﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp333
{
    /// <summary>
    /// Логика взаимодействия для AddPage.xaml
    /// </summary>
    public partial class AddPage : Window
    {
        private Zakaz _currentclient = new Zakaz();
        public AddPage(Zakaz selectedClient)
        {
            InitializeComponent();

            if (selectedClient != null)
                _currentclient = selectedClient;

            DataContext = _currentclient;
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();
            if (string.IsNullOrWhiteSpace(_currentclient.Status))
                errors.AppendLine("error");
           

            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentclient.code == 0)
                pro23Entities.GetContext().Zakaz.Add(_currentclient);

            try
            {
                pro23Entities.GetContext().SaveChanges();
                MessageBox.Show("информация сохранена");
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }
    }
}
